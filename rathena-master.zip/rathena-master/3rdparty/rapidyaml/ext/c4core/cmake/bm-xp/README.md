# Benchmark explorer

You need to start a http server on this folder:

```shellsession
$ python bm.py serve .
```
